import bg from "@/images/backgrounds/watch-video-bg.jpg";

const watchVideo = {
  bg,
  videoId: "Get7rqXYrbQ",
};

export default watchVideo;

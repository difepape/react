const teamOne = {
  title: "meet the team",
  tagline: "people behind it",
  socials: ["fab fa-twitter", "fab fa-facebook", "fab fa-instagram"],
  teams: [
    {
      id: 1,
      image: "team-one-img-1.jpg",
      title: "Developer",
      name: "Sarah albert",
    },
    {
      id: 2,
      image: "team-one-img-2.jpg",
      title: "Developer",
      name: "Sarah albert",
    },
    {
      id: 3,
      image: "team-one-img-3.jpg",
      title: "Developer",
      name: "Sarah albert",
    },
    {
      id: 4,
      image: "team-one-img-4.jpg",
      title: "Developer",
      name: "Sarah albert",
    },
    {
      id: 5,
      image: "team-page-img-5.jpg",
      title: "Developer",
      name: "Sarah albert",
    },
    {
      id: 6,
      image: "team-page-img-6.jpg",
      title: "Developer",
      name: "Sarah albert",
    },
    {
      id: 7,
      image: "team-page-img-7.jpg",
      title: "Developer",
      name: "Sarah albert",
    },
    {
      id: 8,
      image: "team-page-img-8.jpg",
      title: "Developer",
      name: "Sarah albert",
    },
  ],
};

export default teamOne;

const brandOne = [
  "brand-1-1.png",
  "brand-1-2.png",
  "brand-1-3.png",
  "brand-1-4.png",
  "brand-1-5.png",
  "brand-1-1.png",
  "brand-1-2.png",
  "brand-1-3.png",
  "brand-1-4.png",
  "brand-1-5.png",
];

export default brandOne;

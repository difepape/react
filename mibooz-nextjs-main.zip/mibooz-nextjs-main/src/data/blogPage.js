const blogPage = [
  {
    id: 1,
    image: "blog-page-img-1.jpg",
    date: "26 aug",
    admin: "admin",
    comments: 2,
    title: "How much does a website cost to build",
  },
  {
    id: 2,
    image: "blog-page-img-2.jpg",
    date: "26 aug",
    admin: "admin",
    comments: 2,
    title: "Uniquely enable accurate supply chains",
  },
  {
    id: 3,
    image: "blog-page-img-3.jpg",
    date: "26 aug",
    admin: "admin",
    comments: 2,
    title: "task researched data enterprise process",
  },
  {
    id: 4,
    image: "blog-page-img-4.jpg",
    date: "26 aug",
    admin: "admin",
    comments: 2,
    title: "utilize enterprise experiences via 24/7 markets.",
  },
  {
    id: 5,
    image: "blog-page-img-5.jpg",
    date: "26 aug",
    admin: "admin",
    comments: 2,
    title: "actualize front-end processes with effective",
  },
  {
    id: 6,
    image: "blog-page-img-6.jpg",
    date: "26 aug",
    admin: "admin",
    comments: 2,
    title: "array of niche markets through robust products",
  },
];

export default blogPage;

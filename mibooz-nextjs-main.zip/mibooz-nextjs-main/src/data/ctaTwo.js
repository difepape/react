const ctaTwo = {
  icon: "icon-consulting",
  title: "we’re delivering the best \n customer experience",
};

export default ctaTwo;

import bg from "@/images/shapes/services-one-shape.png";

const servicesOne = {
  bg,
  tagline: "Our Services",
  title: "We Shape the \n Perfect solution",
  text: "We are committed to providing our customers with not service while offering our emod tempor incididunt ut labore employees the best training.",
  services: [
    {
      id: 1,
      title: "mobile \n applications",
      icon: "icon-online-shopping",
      link: "/mobile-application",
    },
    {
      id: 2,
      title: "digital \n marketings",
      icon: "icon-growth",
      link: "/digital-marketing",
    },
    {
      id: 3,
      title: "Graphic \n Designings",
      icon: "icon-webpage",
      link: "/graphic-designing",
    },
    {
      id: 4,
      title: "Website \n developments",
      icon: "icon-front-end",
      link: "/website-development",
    },
    {
      id: 5,
      title: "Social \n marketings",
      icon: "icon-bullhorn",
      link: "/social-marketing",
    },
  ],
};

export default servicesOne;

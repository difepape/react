import bg from "@/images/backgrounds/design-studio-bg.jpg";

const designStudio = {
  bg,
  videoId: "Get7rqXYrbQ",
};

export default designStudio;

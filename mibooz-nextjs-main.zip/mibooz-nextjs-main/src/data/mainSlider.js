const mainSlider = [
  {
    id: 1,
    bg: "main-slider-1-1.jpg",
    image: "main-slider-badge.png",
    title: "Creative \n Talent \n Here",
    socials: [
      {
        title: "facebook",
        href: "#",
      },
      {
        title: "twitter",
        href: "#",
      },
      {
        title: "instagram",
        href: "#",
      },
    ],
  },
  {
    id: 2,
    bg: "main-slider-1-2.jpg",
    image: "main-slider-badge.png",
    title: "Creative \n Talent \n Here",
    socials: [
      {
        title: "facebook",
        href: "#",
      },
      {
        title: "twitter",
        href: "#",
      },
      {
        title: "instagram",
        href: "#",
      },
    ],
  },
  {
    id: 3,
    bg: "main-slider-1-3.jpg",
    image: "main-slider-badge.png",
    title: "Creative \n Talent \n Here",
    socials: [
      {
        title: "facebook",
        href: "#",
      },
      {
        title: "twitter",
        href: "#",
      },
      {
        title: "instagram",
        href: "#",
      },
    ],
  },
];

export default mainSlider;

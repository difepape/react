import contentImage from "@/images/resources/why-choose-one-content-img.jpg";
import image from "@/images/resources/why-choose-one-img.jpg";

const WhyChoose = {
  image,
  tagline: "why choose us",
  title: "We do more then ever platform",
  rightText:
    "There are many variations of passages of lorem ipsum available, but the majority have suffered in some form, by injected free text not humour.",
  contentImage,
  points: [
    "Nsectetur cing elit",
    "Suspe ndisse suscip sagittis leo",
    "Entum estib dignissim posuere",
    "If you are going to use a pass",
  ],
  progressTitle: "Digital marketing",
  progressPercent: 66,
};

export default WhyChoose;

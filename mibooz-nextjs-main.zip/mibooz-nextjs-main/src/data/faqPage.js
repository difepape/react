import bg from "@/images/shapes/faq-page-shape.png";

const faqPage = {
  bg,
  bottomText: "Mibooz services built specifically for your business.",
  faqs: [
    [
      {
        id: 1,
        title: "We Help to Create Visual Strategies",
        text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
      },
      {
        id: 2,
        title: "Motion Graphics & Animations",
        text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
      },
      {
        id: 3,
        title: "We Help to Achieve Mutual Goals",
        text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
      },
    ],
    [
      {
        id: 1,
        title: "We Help to Create Visual Strategies",
        text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
      },
      {
        id: 2,
        title: "Motion Graphics & Animations",
        text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
      },
      {
        id: 3,
        title: "We Help to Achieve Mutual Goals",
        text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
      },
    ],
  ],
};

export default faqPage;

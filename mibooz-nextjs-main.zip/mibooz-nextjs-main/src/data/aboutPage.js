import badge from "@/images/resources/about-page-badge.png";

const aboutPage = {
  images: ["about-page-img-1.jpg", "about-page-img-2.jpg"],
  badge,
  tagline: "about company",
  title: "get to know about agency",
  text1:
    "There are many variations of pass of lorem ipsum available but the majority have suffered alteration in some Injected humour randomised words.",
  text2: "providing innovative Website solutions for future.",
};

export default aboutPage;

import image from "@/images/resources/we-build-img.jpg";

const weBuild = {
  image,
  icon: "icon-social-media",
  content: "Founded \n in 1987",
  tagline: "welcome to creative agency",
  title: "We build powerul web designs",
  points: [
    {
      id: 1,
      title: "Highest Success Rates",
      text: "Lorem ipsum available, but the majority have suffered in some form, by injected humour.",
    },
    {
      id: 2,
      title: "real world impact",
      text: "Lorem ipsum available, but the majority have suffered in some form, by injected humour.",
    },
    {
      id: 3,
      title: "unlocking values",
      text: "Lorem ipsum available, but the majority have suffered in some form, by injected humour.",
    },
  ],
};

export default weBuild;

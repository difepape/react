import image from "@/images/resources/we-care-img.jpg";

const weCare = {
  image,
  title: "We Care About Business Growths",
  text: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered.",
};

export default weCare;

const featureOne = [
  {
    id: 1,
    icon: "icon-checking",
    title: "free quotes",
    text: "Lorem ium dolor sit ametad pisicing elit sed do ut.",
  },
  {
    id: 2,
    icon: "icon-graphic-designer",
    title: "super experts",
    text: "Lorem ium dolor sit ametad pisicing elit sed do ut.",
  },
  {
    id: 3,
    icon: "icon-social-media",
    title: "best strategy",
    text: "Lorem ium dolor sit ametad pisicing elit sed do ut.",
  },
  {
    id: 4,
    icon: "icon-recommend",
    title: "quality work",
    text: "Lorem ium dolor sit ametad pisicing elit sed do ut.",
  },
];

export default featureOne;

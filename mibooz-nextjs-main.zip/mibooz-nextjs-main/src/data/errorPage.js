const errorPage = {
  title: "404",
  tagline: "Sorry We Can't Find \n That Page!",
  text: "The page you are looking for was never existed.",
};

export default errorPage;

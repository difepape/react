import React from "react";

const SingleCounter = () => {
  return <div></div>;
};

export default SingleCounter;
